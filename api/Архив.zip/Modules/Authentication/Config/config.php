<?php

return [
    'name' => 'Authentication'
];
