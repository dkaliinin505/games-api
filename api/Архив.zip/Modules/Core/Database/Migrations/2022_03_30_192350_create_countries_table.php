<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCountriesTable extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('countries', function (Blueprint $table) {
            $table->id();

            $table->string("name");
            $table->string("iso2_code", 2)->index("idx_iso2-code")->unique("uidx_iso2-code");
            $table->string("iso3_code", 3)->index("idx_iso3-code")->unique("uidx_iso3-code");

            $table->string("dial_code")->nullable()->index("idx_dial-code");

            $table->string("currency_code")->nullable();
            $table->string("currency_name")->nullable();
            $table->string("currency_symbol")->nullable();

            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('countries');
    }
}
