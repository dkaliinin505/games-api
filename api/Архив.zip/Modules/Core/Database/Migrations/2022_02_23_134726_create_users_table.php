<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\Core\Enum\User\UserTypes;
use Modules\Core\Helpers\Support\Enums;

class CreateUsersTable extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements("id");

            $table->string("name");
            $table->string("slug")->index("idx_users-slug")->unique("uidx_users-slug");

            $table->string("email")->index("idx_users-email")->unique("uidx_users-email");
            $table->timestamp("email_verified_at")->nullable();

            $table->string("phone_number")->nullable()->unique("uidx_phone-number");
            $table->string("phone_number_verified_at")->nullable();

            $table->string("password");

            $table->enum("type", enum_values(UserTypes::class))->default(UserTypes::USER->value)
                ->index("idx_users-type");

            $table->float("balance", unsigned: true)->default(0);

            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('users');
    }
}
