<?php

namespace Modules\Core\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Modules\Core\Entities\Country;
use Modules\Core\Helpers\Filesystem\CountriesFilesystem;

class CountrySeederTableSeeder extends Seeder
{
    const COUNTRIES_API = "https://restcountries.com/v3.1/all";
    const DIAL_CODES_API = "http://country.io/phone.json";
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        $strJsonCountries = file_get_contents(self::COUNTRIES_API);
        $strJsonDialCodes = file_get_contents(self::DIAL_CODES_API);

        $arrApiCountries = json_decode($strJsonCountries, JSON_OBJECT_AS_ARRAY);
        $arrDialCodes = json_decode($strJsonDialCodes, JSON_OBJECT_AS_ARRAY);

        $arrProcessedCountries = [];

        foreach ($arrApiCountries as $arrCountry) {
            $arrData = [
                "name" => $arrCountry["name"]["common"],
                "iso2_code" => strtolower($arrCountry["cca2"]),
                "iso3_code" => strtolower($arrCountry["cca3"]),
            ];

            if (array_key_exists("currencies", $arrCountry)) {
                $strCurrencyCode = array_key_first($arrCountry["currencies"]);
                $arrCurrencyInfo = array_shift($arrCountry["currencies"]);

                $arrData["currency_code"] = strtolower($strCurrencyCode);
                $arrData["currency_name"] = $arrCurrencyInfo["name"];
                $arrData["currency_symbol"] = $arrCurrencyInfo["symbol"] ?? $strCurrencyCode;
            }


            $arrData['dial_code'] = Str::start($arrDialCodes[$arrCountry["cca2"]], "+");
            $arrData["flags"] = $arrCountry["flags"];

            $arrProcessedCountries[] = $arrData;
        }

        $arrProcessedCountries = array_values(Arr::sort($arrProcessedCountries, function ($value) {
            return $value["name"];
        }));


        foreach ($arrProcessedCountries as $country) {
            $arrFlags = $country["flags"];
            unset($country["flags"]);

            $objCountry = Country::create($country);

            CountriesFilesystem::savePngFlag($objCountry, file_get_contents($arrFlags["png"]));
            CountriesFilesystem::saveSvgFlag($objCountry, file_get_contents($arrFlags["svg"]));
        }
    }
}
