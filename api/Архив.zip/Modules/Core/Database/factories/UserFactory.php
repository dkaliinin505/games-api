<?php

namespace Modules\Core\Database\factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Modules\Core\Entities\User;
use Modules\Core\Enum\User\UserTypes;
use Spatie\Sluggable\SlugOptions;

class UserFactory extends Factory {
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = User::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition() {
        $name = $this->faker->name;

        return [
            "name"         => $name,
            "slug"         => Str::slug($name),
            "email"        => $this->faker->email,
            "phone_number" => $this->faker->phoneNumber,
            "password"     => Hash::make("12345678"),
            "type"         => UserTypes::USER->value,
            "balance"      => 0,
        ];
    }
}

