<?php

namespace Modules\Core\Tests\Unit\Helpers\Support;

enum TestEnum: string {
    case ONE = "one";
    case TWO = "two";
    case ANOTHER = "three";
}