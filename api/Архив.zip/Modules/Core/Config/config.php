<?php

return [
    'name' => 'Core'
];
