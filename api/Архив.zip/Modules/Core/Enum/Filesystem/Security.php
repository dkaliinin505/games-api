<?php

namespace Modules\Core\Enum\Filesystem;

enum Security: string {
    case KEYS = "/security/keys";
}