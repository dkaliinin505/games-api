<?php

namespace Modules\User\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Modules\Core\Transformers\UserTransformer;

class UserController extends Controller {
    /**
     * Display a listing of the resource.
     * @return \Modules\Core\Transformers\UserTransformer
     */
    public function getAuthUser(): UserTransformer {
        /** @var \Modules\Core\Entities\User $objUser */
        $objUser = Auth::user();

        return new UserTransformer($objUser);
    }
}
