<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Authentication\\Providers\\AuthenticationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Authentication\\Providers\\AuthenticationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);