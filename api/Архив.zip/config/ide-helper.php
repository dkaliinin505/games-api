<?php

return [
    'model_locations' => [
        'app',
        "Modules/Core/Entities"
    ],
];